# BNew

![ruby-2.7.0](https://img.shields.io/badge/ruby-2.7.0-red.svg) ![rails-6.0.3.1](https://img.shields.io/badge/rails-6.0.3.1-red.svg)

### Installation
Follow the next steps in order to start developing:
  1. Project configuration
  2. System dependencies
  3. Database configuration
  4. Run the server

#### Project configuration
Installing rvm and Ruby. To install rvm use the following [guide](https://rvm.io/rvm/install).
After that install the required ruby, and create the gemset
```sh
$ rvm install 2.7.0
$ rvm use 2.7.0
```

Install bundler gem (at least `2.1.2`)
```sh
$ gem install bundler -v 2.1.2
```

#### System dependencies
Node.js 8 and **npm** (javascript runtime) (At least node version 8.6)
  * Install using [binaries or sources](https://nodejs.org/en/download/)
  * Install using a [package manager](https://nodejs.org/en/download/package-manager/)

Install Yarn package manager following the official [installation guide](https://yarnpkg.com/lang/en/docs/install/)

### Database configuration

We recommend using mysql (`>= 5.7.0`) as it is the database that will run in production.

Authorize your db user to access the project databases (if not using root):
```sh
$ mysql -u root -p
$ CREATE USER 'USERNAME'@'localhost' IDENTIFIED BY 'PASSWORD'; # To create a new user
$ GRANT ALL PRIVILEGES ON bnew_development.* TO 'USERNAME'@'localhost';
$ GRANT ALL PRIVILEGES ON bnew_test.* TO 'USERNAME'@'localhost';
```

### Run the server
Run the following command to install project dependencies, node libraries and set up the database
```sh
$ bin/setup
```

If you are not using the default creadentials to connect to the database (root user with no password), you'll have to update the 'database.yml' file

To run the project we recommend using some tool like [foreman](https://github.com/ddollar/foreman) or [overmind](https://github.com/DarthSim/overmind), to run all the process in the same terminal. And run:
```sh
$ overmind s # or foreman start
```

If you are not going to use any of this tools, run in separate terminal sessions:
```sh
$ bundle exec rails server --binding 0.0.0.0
$ bin/webpack-dev-server
```

