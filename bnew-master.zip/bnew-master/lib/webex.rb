# frozen_string_literal: true

require 'http'

module Webex
  module URL
    AUTHORIZE = 'https://webexapis.com/v1/authorize'
    ACCESS_TOKEN = 'https://webexapis.com/v1/access_token'
    MY_DETAILS = 'https://webexapis.com/v1/people/me'
    CREATE_ACCOUNT = 'https://webexapis.com/v1/people'
  end

  class << self
    def authorization_url(redirect_uri, webex_upn)
      params = {
        client_id: ENV['WEBEX_CLIENT_ID'],
        response_type: 'code',
        redirect_uri: redirect_uri,
        scope: 'spark:all',
        email: webex_upn
      }
      query = params.map { |key, value| "#{key}=#{CGI.escape(value)}" }.join('&')
      "#{Webex::URL::AUTHORIZE}?#{query}"
    end

    def valid_access_token?(access_token)
      HTTP.auth("Bearer #{access_token}").head(URL::MY_DETAILS).status.success?
    end

    def request_access_token(code, redirect_uri)
      HTTP.post(URL::ACCESS_TOKEN, form: {
        grant_type: 'authorization_code',
        client_id: ENV['WEBEX_CLIENT_ID'],
        client_secret: ENV['WEBEX_CLIENT_SECRET'],
        code: code,
        redirect_uri: redirect_uri
      })
    end

    def refresh_access_token(refresh_token)
      HTTP.post(URL::ACCESS_TOKEN, form: {
        grant_type: 'refresh_token',
        client_id: ENV['WEBEX_CLIENT_ID'],
        client_secret: ENV['WEBEX_CLIENT_SECRET'],
        refresh_token: refresh_token
      })
    end

    def generate_upn
      "#{SecureRandom.hex(12)}@bnewbarcelona.com"
    end

    def create_account(webex_upn, first_name, last_name)
      HTTP.auth("Bearer #{ENV['WEBEX_ADMIN_ACCESS_TOKEN']}").post(URL::CREATE_ACCOUNT, form: {
        emails: [webex_upn],
        firstName: first_name,
        lastName: last_name
      })
    end
  end
end
