require 'i18n'

# ACtiveRecord models should extend its TranslatedAttributes submodule
# (e.g. TranslatedAttributes::User for a User model), so thet the model now has
# the translated attributes as a class method (useful for selects with translated values).
module TranslatedAttributes
  # Retrieves the translation identified by key,
  # and sorts the result by value sorted equals true
  def self.t(key, sorted = false)
    value = I18n.translate(key)
    value = value.sort_by { |_, v| v.downcase }.to_h if sorted
    value
  end

  module Sectorable
    def sectors
      TranslatedAttributes.t('attributes.sectorable.sectors', true)
    end
  end

  module User
    def skills
      TranslatedAttributes.t('attributes.user.skills', true)
    end
  end

  module Company
    def industries
      TranslatedAttributes.t('attributes.company.industries', true)
    end

    def roles
      TranslatedAttributes.t('attributes.company.roles', true)
    end

    def departments
      TranslatedAttributes.t('attributes.company.departments', true)
    end

    def bnew_interests
      TranslatedAttributes.t('attributes.company.bnew_interests', true)
    end

    def visit_reasons
      TranslatedAttributes.t('attributes.company.visit_reasons', true)
    end

    def visit_purposes
      TranslatedAttributes.t('attributes.company.visit_purposes', true)
    end

    def employee_ranges
      TranslatedAttributes.t('attributes.company.employee_ranges')
    end
  end
end
