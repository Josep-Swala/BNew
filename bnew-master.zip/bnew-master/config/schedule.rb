# Learn more: http://github.com/javan/whenever
# Set times in UTC, not your current timezone

set :output, './log/cron.log'
set :chronic_options, hours24: true, week_start: :monday, endian_precedence: [:little, :middle]

every :day, at: '07:00' do
  rake 'analytics:user_stages'
  rake 'analytics:export_users'
end
