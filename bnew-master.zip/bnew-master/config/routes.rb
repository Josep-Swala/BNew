require 'sidekiq/web'

Rails.application.routes.draw do
  root to: 'welcome#building'

  devise_for :users, path_names: { sign_in: 'login' }, controllers: { registrations: 'registrations' }

  namespace :webex do
    get :activate
    get :oauth
  end

  resources :archive, only: [:index]
  resources :talks, only: [:index]
  resources :debates, only: [:index, :show]
  resources :businesses, only: [:index, :show]
  namespace :networking do
    root action: :chat
    get :people
  end

  namespace :calendar do
    get 'talk/:id', action: :talk, as: :talk
    get 'debate/:id', action: :debate, as: :debate
  end

  mount LetterOpenerWeb::Engine, at: '/letter_opener' if Rails.env.development?
  match '*path', to: redirect('/'), via: :get unless Rails.env.development?

  scope :sidekiq do
    unless Rails.env.development?
      Sidekiq::Web.use Rack::Auth::Basic do |username, password|
        user = ::Digest::SHA256.hexdigest(username)
        pass = ::Digest::SHA256.hexdigest(password)
        sidekiq_user = ::Digest::SHA256.hexdigest(ENV['SIDEKIQ_USERNAME'])
        sidekiq_pass = ::Digest::SHA256.hexdigest(ENV['SIDEKIQ_PASSWORD'])
        ActiveSupport::SecurityUtils.secure_compare(user, sidekiq_user) && ActiveSupport::SecurityUtils.secure_compare(pass, sidekiq_pass)
      end
    end
    mount Sidekiq::Web, at: '/'
  end
end
