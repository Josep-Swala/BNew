# Base configuration is the same as in production
require File.expand_path('production.rb', __dir__)

Rails.application.configure do
  config.action_mailer.default_url_options = { protocol: 'https', host: 'bnew.emotions-ar.com' }

  # Disable sending emails in staging
  config.action_mailer.delivery_method = :test
  config.action_mailer.perform_deliveries = false
  config.action_mailer.raise_delivery_errors = false
end
