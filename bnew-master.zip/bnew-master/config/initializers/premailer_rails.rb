# Email preprocessor configuration
Premailer::Rails.config.merge!(
  generate_text_part: false,
  remove_ids: true,
  remove_comments: true,
  adapter: :nokogiri
)
