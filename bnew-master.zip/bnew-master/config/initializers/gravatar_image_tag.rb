# Gravatar image defaults
GravatarImageTag.configure do |config|
  config.default_image = :mp
  config.include_size_attributes = true
  config.secure = true
end
