CarrierWave.configure do |config|
  config.cache_dir = Rails.root.join('tmp', 'cache', 'uploads')

  if Rails.env.in? %w[development test]
    config.storage = :file
    config.enable_processing = false if Rails.env.test?
  else
    config.fog_provider = 'fog/aws'
    config.fog_credentials = {
      provider: 'AWS',
      aws_access_key_id: ENV['AWS_ACCESS_KEY_ID'],
      aws_secret_access_key: ENV['AWS_SECRET_ACCESS_KEY'],
      region: ENV['AWS_REGION']
    }
    config.fog_directory = ENV['AWS_S3_BUCKET']
    config.fog_attributes = { cache_control: "public, max-age=#{365.days.to_i}" }
    config.storage = :fog

    config.asset_host = ENV['CONTENT_CDN'] if Rails.env.production?
  end
end
