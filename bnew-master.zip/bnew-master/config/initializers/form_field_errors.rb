# Disaplay error messages with bootstrap
# Extracted from (with a few changes): https://gist.github.com/telwell/db42a4dafbe9cc3b7988debe358c88ad

# rubocop:disable Rails/OutputSafety
ActionView::Base.field_error_proc = proc do |html_tag, instance|
  html = ''
  form_fields = %w[textarea input select]

  elements = Nokogiri::HTML::DocumentFragment.parse(html_tag).css 'label, ' + form_fields.join(', ')
  elements.each do |e|
    case e.node_name
    when 'label'
      html = e.to_s.html_safe
    when *form_fields
      e.add_class 'is-invalid'

      error_message = Array(instance.error_message).uniq.map(&:capitalize).join(', ')
      html = %(#{e}<span class="invalid-feedback font-italic">#{error_message}</span>).html_safe
    end
  end

  html
end
# rubocop:enable Rails/OutputSafety
