class AddCityToCompanies < ActiveRecord::Migration[6.0]
  def change
    add_column :companies, :city, :string, after: :postal_code
  end
end
