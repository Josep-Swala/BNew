class RemoveSectorFromTalks < ActiveRecord::Migration[6.0]
  def change
    remove_column :talks, :sector, :string, null: false, limit: 16, after: :date
  end
end
