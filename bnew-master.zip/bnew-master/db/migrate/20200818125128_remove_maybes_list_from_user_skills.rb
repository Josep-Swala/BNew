class RemoveMaybesListFromUserSkills < ActiveRecord::Migration[6.0]
  def up
    # rubocop:disable Rails/SkipsModelValidations
    ActsAsTaggableOn::Tagging.where(context: 'maybes').update_all(context: 'interests')
    # rubocop:enable Rails/SkipsModelValidations
  end
end
