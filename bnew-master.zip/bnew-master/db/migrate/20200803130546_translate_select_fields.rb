class TranslateSelectFields < ActiveRecord::Migration[6.0]
  # rubocop:disable Rails/SkipsModelValidations
  def up
    I18n.with_locale(:en) do
      skills = I18n.translate('attributes.user.skills')
      skills.each do |key, value|
        ActsAsTaggableOn::Tag.where(name: value.tr(' ', '_').downcase).update_all(name: key)
      end

      [
        { name: :industry, data: I18n.translate('attributes.company.industries') },
        { name: :role, data: I18n.translate('attributes.company.roles') },
        { name: :department, data: I18n.translate('attributes.company.departments') },
        { name: :visit_reason, data: I18n.translate('attributes.company.visit_reasons') },
        { name: :visit_purpose, data: I18n.translate('attributes.company.visit_purposes') }
      ].each do |field|
        field[:data].each do |key, value|
          name = field[:name]
          Company.where(name => value).update_all(name => key)
        end
      end

      bnew_interests = I18n.translate('attributes.company.bnew_interests')
      Company.where.not(bnew_interests: nil).each do |company|
        bnew_interests_as_keys = company.bnew_interests.map do |sector|
          bnew_interests.key(sector).to_s
        end

        company.update!(bnew_interests: bnew_interests_as_keys)
      end
    end
  end
  # rubocop:enable Rails/SkipsModelValidations
end
