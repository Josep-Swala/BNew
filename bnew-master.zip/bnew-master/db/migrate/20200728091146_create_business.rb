class CreateBusiness < ActiveRecord::Migration[6.0]
  def change
    create_table :businesses do |t|
      t.string :name, null: false
      t.string :description, null: false
      t.string :sector, null: false, limit: 16
      t.string :headline
      t.string :website, null: false
      t.string :email, null: false
      t.string :logo, null: false
      t.string :image, null: false
      t.string :video, null: false
      t.string :brochure
      t.timestamps
    end
  end
end
