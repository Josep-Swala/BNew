class AddSectorToTalks < ActiveRecord::Migration[6.0]
  def change
    change_table :talks, bulk: true do |t|
      t.string :sector, null: false, limit: 16, after: :date
    end
  end
end
