class CreateCompanies < ActiveRecord::Migration[6.0]
  def change
    create_table :companies do |t|
      t.references :user, null: false

      t.string :name, null: false
      t.string :description
      t.string :webpage
      t.string :telephone
      t.string :industry
      t.boolean :startup
      t.boolean :hiring
      t.boolean :sdg

      t.string :role, null: false
      t.string :department
      t.string :bnew_interests
      t.string :visit_purpose
      t.string :visit_reason
      t.boolean :decision_maker
      t.string :number_of_employees

      t.string :address
      t.string :secondary_address
      t.string :postal_code
      t.string :province
      t.string :country

      t.timestamps
    end
  end
end
