class AddDiscountCodeToUsers < ActiveRecord::Migration[6.0]
  def change
    add_column :users, :discount_code, :string, after: :webex_refresh_token
  end
end
