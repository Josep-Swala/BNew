class AddWebexToUsers < ActiveRecord::Migration[6.0]
  def change
    change_table :users, bulk: true do |t|
      t.string :webex_upn, after: :last_sign_in_ip
      t.string :webex_access_token, after: :webex_upn
      t.string :webex_refresh_token, after: :webex_access_token
    end
  end
end
