class ActsAsTaggableOnMigration < ActiveRecord::Migration[6.0]
  def up
    create_table ActsAsTaggableOn.tags_table do |t|
      t.string :name
      t.integer :taggings_count, default: 0

      t.timestamps
    end
    execute("ALTER TABLE #{ActsAsTaggableOn.tags_table} MODIFY name varchar(255) CHARACTER SET utf8 COLLATE utf8_bin;")

    create_table ActsAsTaggableOn.taggings_table do |t|
      t.references :tag, foreign_key: { to_table: ActsAsTaggableOn.tags_table }

      t.references :taggable, polymorphic: true
      t.references :tagger, polymorphic: true

      t.string :context, limit: 128

      t.datetime :created_at
    end

    # Indexes
    add_index ActsAsTaggableOn.tags_table, :name, unique: true
    add_index ActsAsTaggableOn.taggings_table, [:tag_id, :taggable_id, :taggable_type, :context, :tagger_id, :tagger_type], unique: true, name: 'taggings_idx'
    add_index ActsAsTaggableOn.taggings_table, [:taggable_id, :taggable_type, :context], name: 'taggings_taggable_context_idx'
    add_index ActsAsTaggableOn.taggings_table, :taggable_id
    add_index ActsAsTaggableOn.taggings_table, :taggable_type
    add_index ActsAsTaggableOn.taggings_table, :tagger_id
    add_index ActsAsTaggableOn.taggings_table, :context
    add_index ActsAsTaggableOn.taggings_table, [:tagger_id, :tagger_type]
    add_index ActsAsTaggableOn.taggings_table, [:taggable_id, :taggable_type, :tagger_id, :context], name: 'taggings_idy'
  end

  def down
    drop_table ActsAsTaggableOn.taggings_table
    drop_table ActsAsTaggableOn.tags_table
  end
end
