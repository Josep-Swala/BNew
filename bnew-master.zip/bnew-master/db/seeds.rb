image = ->(width, height = width) { "https://via.placeholder.com/#{width}x#{height}.png" }

12.times do
  Speaker.create!(
    name: Faker::Name.name_with_middle,
    information: Faker::Quote.famous_last_words,
    remote_image_url: image.call(250, 500)
  )
end

12.times do |index|
  Talk.create!(
    speaker_id: index + 1,
    title: Faker::Lorem.sentence,
    date: Faker::Time.between(from: 2.days.ago, to: 2.days.from_now),
    remote_image_url: image.call(300),
    archive_url: Faker::Internet.url
  )
end

28.times do
  Debate.create!(
    speaker_id: Faker::Number.between(from: 1, to: Speaker.all.size),
    title: Faker::Lorem.sentence,
    date: Faker::Time.between(from: 2.days.ago, to: 2.days.from_now),
    sector: Debate.sectors.keys.sample,
    remote_image_url: image.call(300),
    archive_url: Faker::Internet.url,
    live_stream_url: Faker::Internet.url
  )
end

30.times do
  Interview.create!(
    speaker_id: Faker::Number.between(from: 1, to: Speaker.all.size),
    title: Faker::Lorem.sentence,
    date: Faker::Time.between(from: 2.days.ago, to: 2.days.from_now),
    sector: Interview.sectors.keys.sample,
    archive_url: Faker::Internet.url
  )
end

12.times do
  Business.create!(
    name: Faker::Company.name,
    description: Faker::Lorem.paragraph,
    sector: Business.sectors.keys.sample,
    headline: Faker::Company.catch_phrase,
    website: Faker::Internet.url,
    email: Faker::Internet.email,
    remote_logo_url: Faker::Company.logo,
    remote_image_url: image.call(1080, 720),
    remote_video_url: 'https://file-examples-com.github.io/uploads/2017/04/file_example_MP4_480_1_5MG.mp4'
  )
end

password_generator = lambda do
  Faker::Number.number.to_s + Faker::Internet.password(
    min_length: Devise.password_length.min,
    max_length: Devise.password_length.min,
    mix_case: true
  )
end
roles = Company.roles.keys
industries = Company.industries.keys
departments = Company.departments.keys
visit_reasons = Company.visit_reasons.keys
visit_purposes = Company.visit_purposes.keys
bnew_interests = Company.bnew_interests.keys
employee_ranges = Company.employee_ranges
countries = ISO3166::Country.codes
skills = User.skills.keys

50.times do
  all_skills = skills.dup.shuffle

  user = User.new(
    name: Faker::Name.name_with_middle,
    email: Faker::Internet.email,
    password: password_generator.call,
    mobile_phone: Faker::PhoneNumber.cell_phone,
    company_attributes: {
      name: Faker::Company.name,
      role: roles.sample.to_s,
      industry: industries.sample.to_s,
      department: departments.sample.to_s,
      visit_reason: visit_reasons.sample.to_s,
      visit_purpose: visit_purposes.sample.to_s,
      bnew_interests: bnew_interests.sample(Faker::Number.between(from: 1, to: bnew_interests.size)).map(&:to_s),
      decision_maker: Faker::Boolean.boolean,
      hiring: Faker::Boolean.boolean,
      startup: Faker::Boolean.boolean,
      sdg: Faker::Boolean.boolean,
      number_of_employees: employee_ranges.sample.to_s,
      address: (Faker::Address.street_address if Faker::Boolean.boolean),
      postal_code: Faker::Address.postcode,
      city: Faker::Address.city,
      province: Faker::Address.state,
      country: countries.sample.to_s
    },
    offer_list: all_skills.pop(Faker::Number.between(from: 1, to: all_skills.size)),
    interest_list: all_skills.pop(Faker::Number.between(from: 1, to: all_skills.size))
  )

  if Faker::Boolean.boolean(true_ratio: 0.75)
    user.confirmed_at = Time.current
    user.created_at = Faker::Time.backward
    user.current_sign_in_at = user.created_at
  else
    user.skip_confirmation_notification!
  end

  user.save!
end
