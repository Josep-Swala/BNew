class Speaker < ApplicationRecord
  has_many :talks, dependent: :destroy
  has_many :debates, dependent: :destroy
  has_many :interviews, dependent: :destroy

  has_person_name
  mount_uploader :image, ImageUploader

  validates :first_name, presence: true
  validates :last_name, presence: true
  validates :information, length: { maximum: 255 }, allow_blank: true
  validates :image, presence: true
end
