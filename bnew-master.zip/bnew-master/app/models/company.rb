class Company < ApplicationRecord
  extend TranslatedAttributes::Company

  belongs_to :user

  serialize :bnew_interests, Array

  validates :user, presence: true
  validates :name, presence: true, length: { maximum: 255 }
  validates :webpage, length: { maximum: 255 }, url: true, allow_blank: true
  validates :industry, inclusion: { in: industries.keys.map(&:to_s) }
  validates :role, presence: true, inclusion: { in: roles.keys.map(&:to_s) }
  validates :department, inclusion: { in: departments.keys.map(&:to_s) }
  validates :bnew_interests, array_inclusion: { in: bnew_interests.keys.map(&:to_s) }
  validates :visit_reason, inclusion: { in: visit_reasons.keys.map(&:to_s) }
  validates :visit_purpose, inclusion: { in: visit_purposes.keys.map(&:to_s) }
  validates :decision_maker, boolean: true
  validates :hiring, boolean: true
  validates :startup, boolean: true
  validates :sdg, boolean: true
  validates :number_of_employees, inclusion: { in: employee_ranges }
  validates :description, length: { maximum: 255 }
  validates :telephone, length: { maximum: 255 }
  validates :address, length: { maximum: 255 }
  validates :secondary_address, length: { maximum: 255 }
  validates :postal_code, presence: true, length: { maximum: 255 }
  validates :city, presence: true, length: { maximum: 255 }
  validates :province, presence: true, length: { maximum: 255 }
  validates :country, presence: true, length: { maximum: 255 }, inclusion: { in: ISO3166::Country.codes }

  def full_address(join: ', ')
    [address || secondary_address, postal_code, city, province, country_name].compact.join(join)
  end

  def country_name
    ISO3166::Country.new(country) if country.present?
  end
end
