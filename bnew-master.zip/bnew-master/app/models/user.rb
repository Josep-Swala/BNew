class User < ApplicationRecord
  extend TranslatedAttributes::User

  has_one :company, dependent: :destroy
  accepts_nested_attributes_for :company, update_only: true

  devise :database_authenticatable, :registerable, :confirmable, :recoverable, :rememberable, :validatable, :trackable
  acts_as_taggable_on :offers, :interests
  has_person_name

  validates :email, confirmation: true, length: { maximum: 255 }
  validates :password, format: { with: /(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])/ }, if: -> { send(:password_required?) }
  validates :first_name, presence: true, length: { maximum: 255 }
  validates :last_name, presence: true, length: { maximum: 255 }
  validates :mobile_phone, presence: true, length: { maximum: 255 }
  validates :terms, acceptance: true

  scope :confirmed, -> { where.not(confirmed_at: nil) }
  scope :search, ->(query) { joins(:company).where('first_name LIKE :q OR last_name LIKE :q OR companies.name LIKE :q', q: "%#{query}%") }

  def refresh_webex(access_token, refresh_token)
    update(webex_access_token: access_token, webex_refresh_token: refresh_token)
  end

  def remove_webex!
    update(webex_access_token: nil, webex_refresh_token: nil)
  end
end
