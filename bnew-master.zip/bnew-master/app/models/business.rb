class Business < ApplicationRecord
  include Sectorable

  mount_uploader :logo, ImageUploader
  mount_uploader :image, ImageUploader
  mount_uploader :video, VideoUploader
  mount_uploader :brochure, PDFUploader

  validates :name, presence: true
  validates :description, presence: true, length: { maximum: 255 }
  validates :website, presence: true, url: true
  validates :email, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :logo, presence: true
  validates :image, presence: true
  validates :video, presence: true

  scope :search, ->(query) { where('name LIKE :q', q: "%#{query}%") }
end
