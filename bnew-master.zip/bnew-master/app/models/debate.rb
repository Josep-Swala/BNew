class Debate < ApplicationRecord
  include Sectorable

  belongs_to :speaker

  mount_uploader :image, ImageUploader

  validates :speaker, presence: true
  validates :title, presence: true
  validates :date, presence: true
  validates :image, presence: true
  validates :live_stream_url, url: true, allow_blank: true
  validates :archive_url, url: true, allow_blank: true

  scope :search, ->(query) { joins(:speaker).where('title LIKE :q OR speakers.first_name LIKE :q OR speakers.last_name LIKE :q', q: "%#{query}%") }
end
