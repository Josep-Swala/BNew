# Adds the sector enum and validations to the record
module Sectorable
  extend ActiveSupport::Concern
  extend TranslatedAttributes::Sectorable

  SECTORS = {
    logistics: 'logistics',
    digital_industry: 'digital_industry',
    real_estate: 'real_estate',
    ecommerce: 'ecommerce',
    economic_zones: 'economic_zones'
  }.freeze

  included do
    enum sector: SECTORS
    validates :sector, presence: true, inclusion: { in: sectors.keys }
  end
end
