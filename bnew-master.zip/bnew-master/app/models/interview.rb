class Interview < ApplicationRecord
  include Sectorable

  belongs_to :speaker

  validates :speaker, presence: true
  validates :title, presence: true
  validates :date, presence: true
  validates :archive_url, url: true, allow_blank: true

  scope :search, ->(query) { joins(:speaker).where('title LIKE :q OR speakers.first_name LIKE :q OR speakers.last_name LIKE :q', q: "%#{query}%") }

  before_validation :ensure_date_present

  private

  def ensure_date_present
    self.date = created_at || Time.current if date.blank?
  end
end
