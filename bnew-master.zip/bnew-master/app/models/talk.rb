class Talk < ApplicationRecord
  LIVE_STREAM_URL = 'https://hlsliveamdgl7-lh.akamaihd.net/i/hlsdvrlive_1@583042/master.m3u8'.freeze
  DURATION = 45.minutes.freeze

  belongs_to :speaker

  mount_uploader :image, ImageUploader

  validates :speaker, presence: true
  validates :title, presence: true
  validates :date, presence: true
  validates :image, presence: true
  validates :archive_url, url: true, allow_blank: true

  scope :search, ->(query) { joins(:speaker).where('title LIKE :q OR speakers.first_name LIKE :q OR speakers.last_name LIKE :q', q: "%#{query}%") }
end
