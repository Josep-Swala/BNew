class ApplicationMailer < ActionMailer::Base
  default from: 'BNEW <noreply@bnewbarcelona.com>'
  layout 'mailer'
end
