class AnalyticsMailer < ApplicationMailer
  DEFAULT_EMAILS = ENV.fetch('DEFAULT_ANALYTICS_EMAILS', default[:from])

  default to: DEFAULT_EMAILS
  layout false

  def user_stages(data)
    @data = data

    mail
  end

  def exported_users(files)
    files.each do |file|
      attachments["#{file[:file_name]}.csv"] = {
        mime_type: 'text/csv',
        content: file[:content]
      }
    end

    mail
  end
end
