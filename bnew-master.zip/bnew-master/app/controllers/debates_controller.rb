class DebatesController < ApplicationController
  def index
    debates = Debate.all.where('date > ?', Time.current).includes(:speaker).order(date: :asc)

    @query = params[:query].presence
    @sector = params[:sector].presence

    if @query.present?
      debates = debates.search(@query)
    elsif @sector.present?
      debates = debates.where(sector: @sector)
    end

    @pagy, @debates = pagy(debates)
  end

  def show
    @debate = Debate.all.find_by(id: params[:id])
  end
end
