class NetworkingController < ApplicationController
  include Webexable

  def chat; end

  def people
    @interesting_people = User.confirmed
                              .tagged_with(current_user.interest_list, on: :offers, any: true)
                              .includes(:company)
                              .order(current_sign_in_at: :desc)
    @attendees = User.confirmed
                     .where.not(id: [current_user.id, *@interesting_people.pluck(:id)])
                     .includes(:company)
                     .order(current_sign_in_at: :desc)
                     .distinct

    query = params[:query].presence
    return if query.blank?

    @interesting_people = @interesting_people.search(query)
    @attendees = @attendees.search(query)
  end
end
