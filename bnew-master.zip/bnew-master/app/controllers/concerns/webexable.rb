require 'webex'

module Webexable
  extend ActiveSupport::Concern

  included do
    before_action :require_webex_activated

    def require_webex_activated
      if user_has_webex_access_token?
        return if user_has_valid_webex_access_token?

        refreshed = refresh_user_webex_access_token
        return if refreshed
      end

      flash[:info] = t('.webex_error')
      redirect_to webex_activate_url
    end

    private

    def user_has_webex_access_token?
      current_user.webex_access_token.present?
    end

    def user_has_valid_webex_access_token?
      Webex.valid_access_token? current_user.webex_access_token
    end

    def refresh_user_webex_access_token
      response = Webex.refresh_access_token(current_user.webex_refresh_token)
      if response.status.success?
        data = JSON.parse(response.body.to_s)
        current_user.refresh_webex(data['access_token'], data['refresh_token'])

        true
      else
        current_user.remove_webex!

        false
      end
    end
  end
end
