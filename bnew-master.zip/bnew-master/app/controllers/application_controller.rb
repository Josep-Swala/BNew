class ApplicationController < ActionController::Base
  include Pagy::Backend

  protect_from_forgery

  before_action :authenticate_user!
  before_action :configure_permitted_parameters, if: :devise_controller?
  before_action :prepare_exception_notifier
  around_action :switch_locale

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up, keys: [:email_confirmation, :terms])
  end

  private

  def prepare_exception_notifier
    request.env['exception_notifier.exception_data'] = {
      environment: Rails.env.downcase.to_s,
      user: current_user.try(:email)
    }
  end

  def switch_locale(&action)
    locale = browser_locale || I18n.default_locale
    I18n.with_locale(locale, &action)
  end

  def browser_locale
    locales = request.env['HTTP_ACCEPT_LANGUAGE'] || ''
    locales.scan(/^[a-z]{2}/).find do |locale|
      I18n.available_locales.include?(locale.to_sym)
    end
  end
end
