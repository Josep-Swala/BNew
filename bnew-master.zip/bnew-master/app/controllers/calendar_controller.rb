class CalendarController < ApplicationController
  def talk
    talk = Talk.find_by(id: params[:id])
    return unless talk

    download_calendar(talk.title) do |event|
      event.summary = talk.title
      event.dtstart = talk.date
      event.dtend = talk.date + Talk::DURATION
      event.url = talks_url
    end
  end

  def debate
    debate = Debate.find_by(id: params[:id])
    return unless debate

    download_calendar(debate.title) do |event|
      event.summary = debate.title
      event.dtstart = debate.date
      event.dtend = debate.date + 1.hour
      event.url = debate_url(debate)
    end
  end

  private

  def download_calendar(filename)
    calendar = Icalendar::Calendar.new
    calendar.prodid = t('app_name')
    calendar.x_wr_calname = t('app_name')
    calendar.timezone { |timezone| timezone.tzid = Time.zone.name }
    calendar.event do |event|
      event.organizer = t('app_name')

      yield event if block_given?
    end
    calendar.publish

    send_data(
      calendar.to_ical,
      filename: "#{filename.parameterize}.ics",
      type: 'text/calendar',
      disposition: :attachment
    )
  end
end
