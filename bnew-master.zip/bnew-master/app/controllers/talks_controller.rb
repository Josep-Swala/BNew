class TalksController < ApplicationController
  def index
    now = Time.current.utc
    @last_talk = Talk.all.where('date BETWEEN ? AND ?', now - Talk::DURATION, now).order(date: :desc).take
    talks = Talk.all.where('date > ?', Time.current).includes(:speaker).order(date: :asc)

    query = params[:query].presence
    if query.present?
      talks = talks.search(query)
    end

    @pagy, @talks = pagy(talks)
  end
end
