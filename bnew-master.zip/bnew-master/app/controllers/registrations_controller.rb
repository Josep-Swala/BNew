# We have to override the registrations controller
# so the confirmation instructions flash is shown,
# as it seems to get lost between redirections
class RegistrationsController < Devise::RegistrationsController
  before_action :check_recaptcha, only: [:create]

  def create
    super do |user|
      user.assign_attributes(user_details_params)
      user.assign_attributes(user_skills_params)
      user.save

      if user.valid? && user.persisted?
        CreateWebexAccountJob.perform_later(user)
      end
    end
  end

  protected

  def after_inactive_sign_up_path_for(_resource)
    after_sign_up_path
  end

  def after_sign_up_path_for(_resource)
    after_sign_up_path
  end

  private

  def after_sign_up_path
    new_user_session_path
  end

  def check_recaptcha
    return if verify_recaptcha

    self.resource = resource_class.new sign_up_params
    resource.validate
    set_minimum_password_length
    respond_with_navigational(resource) { render :new }
  end

  def user_details_params
    params.require(:user).permit(:first_name, :last_name, :mobile_phone, :discount_code, company_attributes: [
      :name,
      :description,
      :webpage,
      :telephone,
      :industry,
      :startup,
      :hiring,
      :sdg,
      :role,
      :department,
      :visit_purpose,
      :visit_reason,
      :decision_maker,
      :number_of_employees,
      :address,
      :secondary_address,
      :postal_code,
      :city,
      :province,
      :country,
      bnew_interests: []
    ])
  end

  def user_skills_params
    params.require(:user).permit(:offer_list, :interest_list)
  end
end
