class WelcomeController < ApplicationController
  def building; end
end
