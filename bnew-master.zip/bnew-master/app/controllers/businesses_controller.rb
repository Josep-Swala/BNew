class BusinessesController < ApplicationController
  def index
    businesses = Business.all.order(:name)

    @query = params[:query].presence
    @sector = params[:sector].presence

    if @query.present?
      businesses = businesses.search(@query)
    elsif @sector.present?
      businesses = businesses.where(sector: @sector)
    end

    @pagy, @businesses = pagy(businesses, items: 4)
  end

  def show
    @business = Business.all.find_by(id: params[:id])
  end
end
