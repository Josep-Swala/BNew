class ArchiveController < ApplicationController
  def index
    debates = Debate.where('date < ?', Time.current).includes(:speaker)
    talks = Talk.where('date < ?', Time.current - Talk::DURATION).includes(:speaker)
    interviews = Interview.where('date < ?', Time.current).includes(:speaker)

    @query = params[:query].presence
    @sector = params[:sector].presence

    if @query.present?
      debates = debates.search(@query)
      talks = talks.search(@query)
      interviews = interviews.search(@query)
    elsif @sector.present?
      debates = debates.where(sector: @sector)
      talks = [] # Talks do not have a sector, se we clear the array
      interviews = interviews.where(sector: @sector)
    end

    @pagy, @keynotes = pagy_array((debates + talks + interviews).sort_by(&:date))
  end
end
