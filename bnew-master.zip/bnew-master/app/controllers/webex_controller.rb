require 'webex'

class WebexController < ApplicationController
  before_action :ensure_no_webex

  def activate
    @webex_upn = current_user.webex_upn.presence
    @autorize_url = Webex.authorization_url(webex_oauth_url, @webex_upn) if @webex_upn.present?
  end

  def oauth
    code = params[:code].presence
    if code.blank?
      redirect_to webex_activate_url
      return
    end

    response = Webex.request_access_token(code, webex_oauth_url)
    if response.status.success?
      data = JSON.parse(response.body.to_s)
      current_user.refresh_webex(data['access_token'], data['refresh_token'])

      redirect_to root_url
    else
      current_user.remove_webex!

      redirect_to webex_activate_url
    end
  end

  private

  def ensure_no_webex
    redirect_to root_url if current_user.webex_access_token.present?
  end
end
