class ArrayInclusionValidator < ActiveModel::EachValidator
  def validate_each(record, attribute, value)
    return if value.present? &&
              value.is_a?(Array) &&
              (options[:in] & value).size == value.size

    record.errors.add(attribute, :inclusion)
  end
end
