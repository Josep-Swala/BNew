class BooleanValidator < ActiveModel::Validations::InclusionValidator
  def initialize(options)
    options[:in] ||= [true, false]
    super
  end
end
