require 'webex'

class CreateWebexAccountJob < ApplicationJob
  class BadRequest < HTTP::RequestError; end

  queue_as :default
  retry_on BadRequest

  def perform(user)
    webex_upn = generate_webex_upn
    response = Webex.create_account(webex_upn, user.first_name, user.last_name)
    unless response.status.success?
      raise BadRequest, "Could not create Webex account for: #{user.email}"
    end

    user.update!(webex_upn: webex_upn)
  end

  private

  def generate_webex_upn
    loop do
      token = Webex.generate_upn
      break token unless User.exists?(webex_upn: token)
    end
  end
end
