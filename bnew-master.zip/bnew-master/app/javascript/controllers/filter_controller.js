import { Controller } from 'stimulus'

export default class extends Controller {
  connect() {
    this.filters.forEach(filter => filter.addEventListener('change', this.filter))
  }

  disconnect() {
    this.filters.forEach(filter => filter.removeEventListener('change', this.filter))
  }

  filter = () => {
    Rails.ajax({
      type: 'GET',
      url: `${this.data.get('url')}?${this._urlParams()}`,
      dataType: 'script'
    });
  }

  get filters() {
    return Array.from(this.element.querySelectorAll('select:not(:disabled)'))
  }

  _urlParams() {
    return this.filters.map(filter => `${filter.name}=${filter.value}`).join('&');
  }
}
