import { Controller } from 'stimulus'
import webex from 'webex'

export default class extends Controller {
  static targets = ['recents', 'space']

  connect() {
    if (this.hasRecentsTarget) this.createRecentsWidget()
    if (this.hasSpaceTarget) {
      const destinationType = this.spaceTarget.dataset.destinationType
      const destinationId = this.spaceTarget.dataset.destinationId
      if (destinationType && destinationId) {
        this.createSpaceWidget(destinationType, destinationId)
      }
    }
  }

  disconnect() {
    this.removeRecentsWidget()
    this.removeSpaceWidget()
  }

  createRecentsWidget() {
    const options = {
      accessToken: this.accessToken,
      spaceLoadCount: 25,
      enableUserProfile: false,
      enableUserProfileMenu: false,
      enableSpaceListFilter: true,
      enableAddButton: false
    }
    if (this.hasSpaceTarget) {
      options.onEvent = (eventName, detail) => {
        if (eventName === 'rooms:selected') {
          this.removeSpaceWidget()
          this.createSpaceWidget('email', detail.data.toPersonEmail)
        }
      }
    }

    this.recentsWidget = webex.widget(this.recentsTarget).recentsWidget(options);
  }

  createSpaceWidget(destinationType, destinationId) {
    this.spaceWidget = webex.widget(this.spaceTarget).spaceWidget({
      accessToken: this.accessToken,
      destinationType: destinationType,
      destinationId: destinationId,
      spaceActivities: { files: false, meet: true, message: true, people: false },
      initialActivity: 'message',
      secondaryActivitiesFullWidth: true,
      composerActions: { files: false, meet: true, message: true, people: false }
    });
  }

  removeRecentsWidget() {
    if (this.recentsWidget) {
      this.recentsWidget.remove()
      this.recentsWidget = null
    }
  }

  removeSpaceWidget() {
    if (this.spaceWidget) {
      this.spaceWidget.remove()
      this.spaceWidget = null
    }
  }

  get accessToken() {
    return document.querySelector('meta[name="webex-access-token"]').content
  }
}
