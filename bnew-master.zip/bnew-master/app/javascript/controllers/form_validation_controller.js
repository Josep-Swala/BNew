import { Controller } from 'stimulus'

export default class extends Controller {
  connect() {
    this.element.setAttribute('novalidate', true);
    this.element.addEventListener('submit', this.onSubmit);
    this.element.addEventListener('ajax:beforeSend', this.onSubmit);
  }

  disconnect() {
    this.element.removeEventListener('submit', this.onSubmit);
    this.element.removeEventListener('ajax:beforeSend', this.onSubmit);
  }

  onSubmit = (event) => {
    if (!this.validateForm()) {
      event.preventDefault();
      event.stopPropagation();
      this.firstInvalidField.focus();
    }
  }

  validateForm() {
    let isValid = true;
    this.formFields.forEach((field) => {
      if (!this.validate(field)) isValid = false;
    })
    return isValid;
  }

  validate(field) {
    const isValid = field.checkValidity();
    field.classList.toggle('is-invalid', !isValid);
    this.refreshErrorMessage(field, isValid);
    return isValid;
  }

  refreshErrorMessage(field, isValid) {
    this.removeErrorMessage(field);
    if (!isValid) this.showErrorMessage(field);
  }

  removeErrorMessage(field) {
    const error = field.parentNode.querySelector('.invalid-feedback');
    if (error) error.parentNode.removeChild(error);
  }

  showErrorMessage(field) {
    field.insertAdjacentElement('afterend', this.generateErrorElement(field));
  }

  generateErrorElement(field) {
    const error = document.createElement('span');
    error.className = 'invalid-feedback font-italic';
    error.innerText = field.validationMessage;
    return error;
  }

  get formFields() {
    const validInputs = ['input', 'textarea', 'select'];
    const disabledTypes = ['file', 'reset', 'submit', 'button', 'hidden'];
    return Array.from(this.element.elements).filter(field => {
      const validInput = validInputs.includes(field.nodeName.toLowerCase());
      const disabledType = disabledTypes.includes(field.type);
      return !field.disabled && validInput && !disabledType;
    });
  }

  get firstInvalidField() {
    return this.formFields.find(field => !field.checkValidity());
  }
}
