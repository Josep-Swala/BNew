import { Controller } from 'stimulus'
import 'select2'
import 'select2/dist/js/i18n/en'
import 'select2/dist/js/i18n/es'

export default class extends Controller {
  connect() {
    $(this.element).select2({
      closeOnSelect: false,
      language: document.documentElement.lang,
      minimumResultsForSearch: Infinity,
      theme: 'bootstrap4',
    })
  }

  disconnect() {
    $(this.element).select2('destroy')
  }
}
