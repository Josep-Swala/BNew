import { Controller } from 'stimulus'
import Sortable from 'sortablejs'

export default class extends Controller {
  static targets = ['skillset', 'container', 'error']

  connect() {
    const group = 'skills'
    this.sortables = [Sortable.create(this.skillsetTarget, { group })]
    this.sortables.concat(this.containerTargets.map(it => Sortable.create(it, { group })))

    this.form.addEventListener('submit', this.submit)
  }

  disconnect() {
    this.form.removeEventListener('submit', this.submit)
    this.sortables.forEach(it => it.destroy())
    this.sortables = null
  }

  submit = (event) => {
    let valid = true

    const element = event.target
    this.containerTargets.forEach(container => {
      const elements = Array.from(container.children, it => it.dataset.value)
      if (elements.length) {
        const input = this._createHiddenInput(container.dataset.param, elements.join(','))
        element.insertAdjacentElement('afterbegin', input)
      } else {
        valid = false
      }
    })

    this._toggleError(valid)
    if (!valid) {
      event.preventDefault()
      event.stopPropagation()
    }
  }

  _createHiddenInput(name, value) {
    const inputName = this._toParam(name)
    let input = document.querySelector(`input[type="hidden"][name="${inputName}"]`)
    if (input) input.remove()

    input = document.createElement('input')
    input.type = 'hidden'
    input.name = inputName
    input.value = value
    return input
  }

  _toParam(param) {
    const rootParam = this.data.get('rootParam')
    if (rootParam) {
      return `${rootParam}[${param}]`
    } else {
      return param
    }
  }

  _toggleError(valid) {
    if (!this.hasErrorTarget || !this.data.has('errorToggleClass')) return

    const errorClass = this.data.get('errorToggleClass')
    if (valid) {
      this.errorTarget.classList.remove(errorClass)
    } else {
      this.errorTarget.classList.add(errorClass)
    }
  }

  get form() {
    return this.element.closest('form')
  }
}
