import { Controller } from 'stimulus'
import videojs from 'video.js'
import 'videojs-contrib-quality-levels'
import 'videojs-hls-quality-selector'

export default class extends Controller {
  connect() {
    this.player = videojs(this.video, {
      html5: {
        hls: {
          overrideNative: true
        }
      }
    })
    this.player.hlsQualitySelector({
      displayCurrentQuality: true
    })
    if (this.data.has('class')) {
      this.video.className += ` ${this.data.get('class')}`
    }
  }

  disconnect() {
    this.player.dispose()
    this.player = null
  }

  get video() {
    return this.element.querySelector('video')
  }
}
