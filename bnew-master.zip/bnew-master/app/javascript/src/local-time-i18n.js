import LocalTime from 'local-time'

LocalTime.config.locale = document.documentElement.lang
LocalTime.config.defaultLocale = "en"

LocalTime.config.i18n["es"] = {
  date: {
    dayNames: [
      "Domingo",
      "Lunes",
      "Martes",
      "Miércoles",
      "Jueves",
      "Viernes",
      "Sábado"
    ],
    abbrDayNames: [
      "Dom",
      "Lun",
      "Mar",
      "Mié",
      "Jue",
      "Viw",
      "Sáb"
    ],
    monthNames: [
      "Enero",
      "Febrero",
      "Marzo",
      "Abril",
      "Mayo",
      "Junio",
      "Julio",
      "Agosto",
      "Septiembre",
      "Octubre",
      "Noviembre",
      "Diciembre"
    ],
    abbrMonthNames: [
      "Ene",
      "Feb",
      "Mar",
      "Abr",
      "May",
      "Jun",
      "Jul",
      "Ago",
      "Sep",
      "Oct",
      "Nov",
      "Dic"
    ],
    yesterday: "ayer",
    today: "hoy",
    tomorrow: "mañana",
    on: "el {date}",
    formats: {
      default: "%e de %b de %Y",
      thisYear: "%e de %b"
    }
  },
  time: {
    am: "am",
    pm: "pm",
    singular: "un {time}",
    singularAn: "una {time}",
    elapsed: "hace {time}",
    second: "segundo",
    seconds: "segundos",
    minute: "minuto",
    minutes: "minutos",
    hour: "hora",
    hours: "horas",
    formats: {
      default: "%H:%M"
    }
  },
  datetime: {
    at: "{date} a las {time}",
    formats: {
      default: "%A, %d de %B de %Y %H:%M:%S %Z"
    }
  }
}
