// In the future we will replace this a specific set of icons
// in order to reduce drastically the final bundle size
// and reduce the page load time
import '@fortawesome/fontawesome-free/js/all'
