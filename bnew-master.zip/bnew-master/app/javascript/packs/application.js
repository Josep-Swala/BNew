import 'core-js/stable'
import 'regenerator-runtime/runtime'
import 'bootstrap'
import LocalTime from 'local-time'
import '../src/local-time-i18n'

LocalTime.start()

require("@rails/ujs").start();
require("turbolinks").start();
require("controllers");

$(document).on('turbolinks:load', function () {
  LocalTime.config.locale = document.documentElement.lang || LocalTime.config.defaultLocale;

  $('form').attr('data-controller', 'form-validation')
  $('input[type="url"]').bind('blur keydown', function (e) {
    if (e.type === 'blur' || e.keyCode === 13) {
      const schemaRE = /^https?:\/\//;

      let value = $(this).val().trim()
      if (value !== "" && !schemaRE.test(value)) {
        value = `http://${value}`;
      }

      $(this).val(value);
    }
  });
})
