class ImageUploader < ApplicationUploader
  def content_type_whitelist
    /image\//
  end
end
