class VideoUploader < ApplicationUploader
  def content_type_whitelist
    /video\//
  end
end
