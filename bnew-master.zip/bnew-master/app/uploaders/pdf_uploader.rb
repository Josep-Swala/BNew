class PDFUploader < ApplicationUploader
  def content_type_whitelist
    'application/pdf'
  end
end
