# Helper methods to display flash messages with a nice design
module FlashMessagesHelper
  # Maps the flash message type to its bootstrap class
  def flash_message_class(flash_type)
    {
      error: 'alert-danger',
      alert: 'alert-warning',
      notice: 'alert-info'
    }[flash_type.to_sym] || "alert-#{flash_type}"
  end

  # Returns an icon representation of the flash message type
  def flash_message_icon(flash_type)
    case flash_type
    when 'error', 'danger'
      'times'
    when 'alert', 'warning'
      'exclamation-triangle'
    when 'notice', 'info'
      'info'
    when 'success'
      'check'
    else
      'question'
    end
  end
end
