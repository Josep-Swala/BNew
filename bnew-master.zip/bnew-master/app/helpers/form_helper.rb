module FormHelper
  def options_from_hash_for_select(hash, selected = nil)
    options_from_collection_for_select(hash, :first, :last, selected)
  end

  def boolean_select(form, attribute, options = {}, html_options = {})
    selected = options.delete(:selected) if options.key?(:selected)
    unless selected
      selected = (form.object.public_send(attribute) ? '1' : '0') if form.object.persisted?
    end

    form.select(attribute, options_for_select(boolean_options, selected), options, html_options)
  end

  private

  def boolean_options
    [[I18n.t('general.yes'), 1], [I18n.t('general.no'), 0]].freeze
  end
end
