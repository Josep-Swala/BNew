require 'test_helper'

class TalkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
