require 'test_helper'

class DebateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
