require 'test_helper'

class AnalyticsMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
