# Preview all emails at http://localhost:3000/rails/mailers/analytics_mailer
class AnalyticsMailerPreview < ActionMailer::Preview
  def user_stages
    AnalyticsMailer.user_stages({
      date: '05/08/2020 09:00:00',
      total: 1413,
      unconfirmed: 331,
      unregistered: 195,
      halfway: 127,
      completed: 760
    })
  end

  def exported_users
    files = [{
      file_name: SecureRandom.urlsafe_base64,
      content: SecureRandom.hex
    }]
    AnalyticsMailer.exported_users(files)
  end
end
