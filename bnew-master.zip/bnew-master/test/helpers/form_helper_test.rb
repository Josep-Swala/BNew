require 'test_helper'

class FormHelperTest < ActionView::TestCase
  # test "the truth" do
  #   assert true
  # end
end
