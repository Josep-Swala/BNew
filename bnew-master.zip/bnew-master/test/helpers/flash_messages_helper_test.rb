require 'test_helper'

class FlashMessagesHelperTest < ActionView::TestCase
  # test "the truth" do
  #   assert true
  # end
end
