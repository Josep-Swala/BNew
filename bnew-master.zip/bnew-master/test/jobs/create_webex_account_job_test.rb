require 'test_helper'

class CreateWebexAccountJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
